<?php
class Adminmodel extends CI_Model {
    public function __construct() {
        parent::__construct();
    }
}