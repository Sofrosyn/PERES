<?php
$lang["first_name"] = "First Name";
$lang["last_name"] = "Last Name";
$lang["msg_dob"] = "Date of Birth";
$lang["address"] = "Address";

?>